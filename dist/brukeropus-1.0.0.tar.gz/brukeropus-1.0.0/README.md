# Bruker OPUS
`brukeropus` is a Python package for interacting with Bruker's OPUS spectroscopy software. Currently, the package can
read OPUS data files and communicate/control OPUS through the DDE interface (e.g. for scripting measurement sequences).
## Reading OPUS Data Files
`brukeropus` can read the binary data files saved by OPUS. The parsing algorithm in this package is more complete than
previous efforts, with a goal to achieve 100% extraction accuracy.
### Features
- Extracts spectral data (e.g. sample, reference, absorbance, transmittance, etc.)
- Extracts 3D spectral data (e.g. spectral time series)
- Extracts file metadata (e.g. beamsplitter, source, aperture, etc.)
- Very fast data parsing and assigning to `OPUSFile` class (limited by disk I/O)
- Low-level parsing functions are well documented and could be used to build your own custom OPUS file class if
`OPUSFile` does not suit your needs)
### Usage
```python
from brukeropus import read_opus
from matplotlib import pyplot as plt

opus_file = read_opus('file.0')  # Returns an OPUSFile class

opus_file.print_parameters()  # Pretty prints all metadata in the file to the console

if 'a' in opus_file.data_keys:  # If absorbance spectra was extracted from file
    plt.plot(opus_file.a.x, opus_file.a.y)  # Plot absorbance spectra
    plt.title(opus_file.sfm + ' - ' + opus_file.snm)  # Sets plot title to Sample Form - Sample Name
    plt.show()  # Display plot
```
### Known Limitations
- While all metadata can be be extracted as key: val pairs, the keys are stored as three characters (e.g. BMS, SRT, SRC)
and are not particularly descriptive.  This package has human readable labels for over 100 of these metadata keys, but
it is not complete.

    - OPUS software should be using a local file (perhaps PARMTEXT.bin) to convert these keys to human readable lables.
    it would be ideal to extract these labels directly from this file rather than manually adding them by hand as is
    currently done.

- I have only tested this on ~5000 files generated in my lab (all very similiar) as well as a handful of files I've
found online (most of which had some error when being read by other tools). This package is capable of reading all of
those files, but thorough testing on a wide variety of files is incomplete.

    - If you have a file that cannot be read by `brukeropus`, please open an issue with a description about the file and
    what seems to be failing.  Also provide a link for me to download the file.  Make sure the file can be read by OPUS
    first (i.e. if the file is corrupted and unreadable by OPUS then `brukeropus` will not be able to read it either).
## Controlling OPUS Software
`brukeropus` can send commands and perform queries to an OPUS software instance through the DDE communication protocol.
OPUS must be open and logged in on the same PC where `brukeropus` is called from to operate.
### Features
- Initiate a sample or reference measurement
- Change/define measurement parameters prior to performing measurement (useful for sweeping parameters like aperture
size, mirror velocity, etc.)
- Send commands for interacting with motors and other accessories (e.g. moving mirrors, rotating polarizers, etc.)
- Control vacuum operation for vacuum-equipped spectrometers (e.g. Vertex 80V FTIR)
- Unload files from OPUS software (so they can be unlocked for moving, renaming, etc.)
### Usage
```python
from brukeropus import opus, read_opus
from matplotlib import pyplot as plt

opus = Opus()  # Connects to actively running OPUS software

apt_options = opus.get_param_options('apt') # Get all valid aperture settings

for apt in apt_options[2:-2]: # Loop over all but the two smallest and two largest aperature settings
    filepath = opus.measure_sample(apt=apt, nss=10, unload=True) # Perform measurement and unload file from OPUS
    data = read_opus(filepath) # Read OPUS file from measurement
    plt.plot(data.sm.x, data.sm.y, label=apt) # Plot single-channel sample spectra
plt.legend()
plt.show()
```
## Future Plans
- Continue to improve the file reader towards 100% compliance
- Parse "PARMTEXT.BIN" file to extract all parameter labels and setup options
- Add a basic GUI for browsing OPUS files
## Installation
**Requirements**
- Python 3.6+
- numpy

**Optional**
- matplotlib (for plotting examples)
### pip
```python
pip install brukeropus
```
## Documentation
https://joshduran.github.io/brukeropus/brukeropus.html

